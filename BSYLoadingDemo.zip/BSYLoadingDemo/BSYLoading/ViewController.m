//
//  ViewController.m
//  BSYLoading
//
//  Created by 白仕云 on 2018/5/17.
//  Copyright © 2018年 BSY.com. All rights reserved.
//

#import "ViewController.h"
#import "BSYLoading.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UIButton *btn = [UIButton buttonWithType:UIButtonTypeContactAdd];
    btn.frame = CGRectMake(0, 0, 100, 100);
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(Click) forControlEvents:UIControlEventTouchUpInside];


    UIButton *btnQ = [UIButton buttonWithType:UIButtonTypeContactAdd];
    btnQ.frame = CGRectMake(0, 250, 100, 100);
    [self.view addSubview:btnQ];
    [btnQ addTarget:self action:@selector(ClickQQQQ) forControlEvents:UIControlEventTouchUpInside];
}

- (void)ClickQQQQ {
    [BSYLoading hidenCrazyCircleAnimation];
}
- (void)Click {
    [BSYLoading showCrazyCircleWithColor:[UIColor redColor] Text:nil TextColor:[UIColor yellowColor]];
}

@end
